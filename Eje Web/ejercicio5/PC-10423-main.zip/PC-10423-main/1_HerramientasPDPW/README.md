# Fundamentos técnicos de una página web
## ¿Que es hipertexto?
Es un conjunto estructurado de textos, gráficos, etc. Unidos entre si jpor enlaces y conexiones lógicas. Las relaciones en el hipertexto se establecen entre lo que se suele llamar como referencias, enlaces, vinculos o hipervinculos. 

## Lenguajes de marcado o etiquetas
Los lenguajes de etiquetas, también conocidos como lenguajes de marcodo o marcas, son los que nos permiten estructurar un documento mediante el uso de etiquetas. Los lenguajes de etiquetas kno se identifican con los lenguajes de programación esto ocurre principalmento porque los lenguajes de etiquetas no definen algunos aspectos básicos presentes en lo lenguajes de programacion, como es el caso de funciones artiméticas.

## Tecnológias de software para el desarrollo de páginas web
|Tecnología| Descripción|
|-|-|
|CSS|Cascading Style Sheets: tiene como función establecer reglas de representación de un documento en un medio o dispositivo. Mediante estas reglas podremos establecer medidas, colores o cualquier otra característica de representación de una página web., para que se vea reflejada en una pantalla.
